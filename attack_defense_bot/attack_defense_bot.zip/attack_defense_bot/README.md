﻿# 安全 RAG 助手 - 2024012348

基于课程 Python 框架完成输入护栏、RAG 检索处理、安全提示词与输出校验。
默认只读查询 `common_dataset`。运行问答不需要公开数据集或其他外部本地文件。

## 本地运行

建议 Python 3.10 或更新版本。仅依赖 requests；Windows、Linux 均可运行。

```powershell
python -m pip install -r requirements.txt
python setup_token.py --token-file "C:\你的路径\2024012348.token.json"
python main.py --check-public-corpus
python main.py --query "什么是最小权限原则？"
python main.py
```

也可复制 `.env.example` 为 `.env`，填写本人 `RAG_API_TOKEN`；环境变量优先于 `.env`。
凭据仅保留在本地 `.env` 或环境变量中，不会进入提示词；Settings 的 repr 隐藏凭据。
课程内网 IP 默认绕过环境中的互联网代理；如所在网络必须通过代理访问，设置环境变量 `RAG_USE_ENV_PROXY=1`。
程序输出 JSON，字段为 `decision`、`answer`、`evidence`、`explanation`。
学号用于交付标识；实际 API 授权由 Token 决定，配置脚本会检查 Token 文件中的学号。

## 测试与复现

在代码目录执行：

```powershell
python -m unittest discover -s tests -v
python eval_offline.py --dataset "C:\你的路径\public_dataset.jsonl" --output-dir output/offline
python smoke_api.py --output output/api_smoke.json
python eval_dataset.py --dataset "C:\你的路径\public_dataset.jsonl" --limit 10 --concurrency 1 --stop-on-error --output-dir output/small_online
python eval_dataset.py --dataset "C:\你的路径\public_dataset.jsonl" --concurrency 3 --progress-every 20 --output-dir output/full_online
```

`smoke_api.py` 在网络和 Token 可用时会创建/复用本人 `rag_demo_2024012348` 演示库，上传一条自编概念摘要并测试个人库检索。
该脚本使用建库响应中的实际名称，重复执行会尽量复用演示记录；不会写入或删除公共库，不会删除任何数据库。
演示库是接口验证用途，正式问答继续查询公共库，避免仅有一条资料导致知识覆盖下降。
接口不可达时报告失败并将后续步骤标记为 `not_run`；不会输出伪造的在线成功记录。

## 实现

- `prompt_builder.py`：固定应用策略、HTML 实体转义的数据块、引用编号、JSON 输出约束；维持原函数签名。
- `guard.py`：NFKC/零宽字符处理，行为与对象组合的风险规则，区分分析问题与执行要求，完整模板校验及输出合约校验。
- `data_processor.py`：按分数过滤，段落级污染隔离，规范化去重、向量分数与关键词覆盖率轻量重排；预算计入分隔符，引用只针对实际保留材料。
- `main.py`：串联输入、检索、处理、提示词、模型和输出校验；非法输入在联网前拦截。
- `api_client.py`、`config.py`：Bearer 请求头、超时、错误脱敏、参数范围检查；保留课程接口。
- `eval_dataset.py`：保留课程完整评估器；`eval_offline.py` 单独测量本地护栏。
- `tests/test_security.py`：14 项离线回归测试，覆盖跨模块链路和关键安全性质。

参数初始值沿用课程框架：top_k=5、max_files=5、max_chars=6000、cosine、score_threshold=0、temperature=0.2。
重排增量权重 0.15 是待校准的工程初值，没有宣称为最优。未使用公开数据集标准答案作为运行时知识库。

## 已知限制

当前网络连接课程接口超时，尚未确认真实模型输出格式、语料相关性、知识题正确率和延迟。
离线护栏在公开开发集上的成绩不能代表完整问答正确率或隐藏集结果；规则对语义变体、多轮诱导和分析问题仍可能漏检或误杀。
课程后端把 custom_prompt 与 user_input 拼接成文本，应用策略不等同于模型原生的系统消息隔离。
HTML 转义和标签校验用于结构防护，不能保证模型语义上完全免疫注入。
引用范围检查能保证编号存在，不能证明回答得到材料蕴含支持。遇到格式错误会明确报错，不静默伪造答案。
多轮记忆模块保留但主流程未启用；本周未实现可视化前端和系统性扩展知识库。

## 提交包

网络学堂进展包：代码、进展报告与离线验证证据，不含真实 Token。
课程在线测评包：只有单层 `attack_defense_bot/` 代码目录，包含已配置的私密 `.env`，不含数据集、报告、日志或缓存；只交给课程指定测评平台，不上传公共仓库。
如需分享代码，请使用进展包内的无凭据版本。
