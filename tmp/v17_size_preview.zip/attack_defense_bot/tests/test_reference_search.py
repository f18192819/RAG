import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import reference_search as module
from retrieval import fuse_rankings


class ReferenceSearchTests(unittest.TestCase):
    def test_source_question_rank_and_unicode_record_boundaries(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            (root/'knowledge').mkdir()
            rows=[['101','Question: Nmap maximum probe spacing?\nAnswer: --max-scan-delay <time>'],
                  ['102','Question: Unicode separator?\nAnswer: alpha\u2028beta\u2029gamma'],
                  ['103','Question: General network monitoring?\nAnswer: Collect traffic telemetry.']]
            (root/'knowledge/course_reference.jsonl').write_text(
                '\n'.join(json.dumps(row,ensure_ascii=False) for row in rows),encoding='utf-8')
            with patch.object(module,'__file__',str(root/'reference_search.py')), \
                 patch.object(module,'_connection',None),patch.object(module,'_documents',[]):
                try:
                    first=module.reference_search('Nmap maximum probe spacing',1)
                    self.assertEqual(first[0]['file_id'],'101')
                    self.assertIn('--max-scan-delay',first[0]['text'])
                    second=module.reference_search('Unicode separator',1)
                    self.assertIn('alpha\u2028beta\u2029gamma',second[0]['text'])
                finally:
                    if module._connection:module._connection.close()

    def test_remote_and_lexical_document_ids_deduplicate(self):
        a={'file_id':101,'text':'One source document.','score':.8}
        b={'file_id':'101','text':'One source document.','score':1.0}
        found=fuse_rankings([(1.0,[a]),(1.0,[b])],5)
        self.assertEqual(len(found),1)


if __name__=='__main__':unittest.main()
